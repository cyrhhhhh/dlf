import unittest
import torch
from trains.singleTask.model.CCDR import (
    CCDR, ModalityBalancedAttentionPool, ReliabilityWeightedAttentionPool,
)


class ReliabilityConsensusTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(17)
        self.features = [torch.randn(5, 2, 4) for _ in range(3)]
        self.masks = [torch.tensor([[False, False, False, True, True],
                                    [False, False, True, True, True]]) for _ in range(3)]

    def test_initialization_matches_equal_pool(self):
        equal = ModalityBalancedAttentionPool(4, 0).eval()
        weighted = ReliabilityWeightedAttentionPool(4, 0).eval()
        weighted.scorer.load_state_dict(equal.scorer.state_dict())
        baseline, _ = equal(self.features, self.masks)
        actual, attention, weights = weighted(self.features, self.masks)
        torch.testing.assert_close(actual, baseline)
        torch.testing.assert_close(weights, torch.full((2, 3), 1/3))
        for attn, mask in zip(attention, self.masks):
            self.assertEqual(attn[mask.T].abs().sum().item(), 0)

    def test_padding_does_not_change_weights_or_output(self):
        pool = ReliabilityWeightedAttentionPool(4, 0).eval()
        torch.nn.init.normal_(pool.reliability[-1].weight)
        changed = [f.masked_fill(m.T.unsqueeze(-1), 10000)
                   for f, m in zip(self.features, self.masks)]
        a, _, wa = pool(self.features, self.masks)
        b, _, wb = pool(changed, self.masks)
        torch.testing.assert_close(a, b)
        torch.testing.assert_close(wa, wb)
        torch.testing.assert_close(wa.sum(-1), torch.ones(2))
        self.assertFalse(torch.allclose(wa[0], wa[1]))

    def test_training_updates_reliability(self):
        pool = ReliabilityWeightedAttentionPool(4, 0)
        optimizer = torch.optim.SGD(pool.parameters(), lr=0.1)
        for _ in range(2):
            optimizer.zero_grad()
            pooled, _, _ = pool(self.features, self.masks)
            pooled.square().mean().backward()
            self.assertGreater(pool.reliability[-1].weight.grad.abs().sum().item(), 0)
            optimizer.step()
        self.assertGreater(pool.reliability[0].weight.grad.abs().sum().item(), 0)
        _, _, weights = pool(self.features, self.masks)
        self.assertFalse(torch.allclose(weights, torch.full((2, 3), 1/3)))

    def test_full_ccdr_initial_equivalence_and_serialization(self):
        torch.manual_seed(4)
        equal = CCDR(4, 2, dropout=0).eval()
        torch.manual_seed(4)
        weighted = CCDR(4, 2, dropout=0, consensus_fusion='reliability').eval()
        for key, value in equal.state_dict().items():
            torch.testing.assert_close(value, weighted.state_dict()[key])
        a = equal(self.features, self.features, self.masks)
        b = weighted(self.features, self.features, self.masks)
        torch.testing.assert_close(a['output_logit'], b['output_logit'])
        clone = CCDR(4, 2, dropout=0, consensus_fusion='reliability').eval()
        clone.load_state_dict(weighted.state_dict(), strict=True)
        torch.testing.assert_close(b['output_logit'], clone(self.features, self.features, self.masks)['output_logit'])

    def test_empty_modality_rejected(self):
        self.masks[0][:] = True
        with self.assertRaises(ValueError):
            ReliabilityWeightedAttentionPool(4)(self.features, self.masks)


if __name__ == '__main__':
    unittest.main()
