import unittest
import torch
from trains.singleTask.model.CCDR import CCDR, FixedWeightedAttentionPool


class FixedConsensusTest(unittest.TestCase):
    def test_global_weights_learn_and_remain_sample_independent(self):
        pool = FixedWeightedAttentionPool(4, 0)
        features = [torch.full((3, 2, 4), float(i)) for i in (1, 2, 4)]
        _, _, w = pool(features)
        torch.testing.assert_close(w, torch.full((2, 3), 1/3))
        optimizer = torch.optim.SGD(pool.parameters(), lr=0.1)
        summary, _, _ = pool(features)
        summary.square().mean().backward()
        self.assertGreater(pool.global_logits.grad.abs().sum().item(), 0)
        optimizer.step()
        _, _, w = pool([torch.randn(3, 5, 4) for _ in range(3)])
        torch.testing.assert_close(w, w[0].expand(5, -1))
        torch.testing.assert_close(w.sum(-1), torch.ones(5))
        self.assertFalse(torch.allclose(w[0], torch.full((3,), 1/3)))
        self.assertFalse(hasattr(pool, 'reliability'))
        self.assertEqual(pool.global_logits.numel(), 3)

    def test_initial_full_model_matches_equal_and_roundtrips(self):
        torch.manual_seed(17)
        equal = CCDR(4, 2, dropout=0).eval()
        torch.manual_seed(17)
        fixed = CCDR(4, 2, dropout=0, consensus_fusion='fixed').eval()
        features = [torch.randn(4, 2, 4) for _ in range(3)]
        masks = [torch.tensor([[False, False, True, True], [False, False, False, True]]) for _ in range(3)]
        a = equal(features, features, masks)
        b = fixed(features, features, masks)
        torch.testing.assert_close(a['output_logit'], b['output_logit'])
        with torch.no_grad(): fixed.consensus_pool.global_logits.copy_(torch.tensor([1., -1., 0.]))
        clone = CCDR(4, 2, dropout=0, consensus_fusion='fixed').eval()
        clone.load_state_dict(fixed.state_dict(), strict=True)
        torch.testing.assert_close(fixed(features, features, masks)['output_logit'], clone(features, features, masks)['output_logit'])


if __name__ == '__main__': unittest.main()
