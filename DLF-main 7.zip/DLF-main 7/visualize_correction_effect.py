"""Compare whether additive CCDR corrections reduce per-sample absolute error."""

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

from config import get_config_regression
from data_loader import MMDataset
from trains.singleTask.model.SerialDLF import DLF


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/config.json"))
    parser.add_argument("--baseline", type=Path, default=Path("pt/DLF-mosi-serial-ccdr.pth"))
    parser.add_argument(
        "--candidate",
        type=Path,
        default=Path("pt/DLF-mosi-serial-ccdr-no-support-correction.pth"),
    )
    parser.add_argument("--candidate-name", default="no_support")
    parser.add_argument("--split", choices=("valid", "test"), default="test")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--output-dir", type=Path, default=Path("result/correction_effect"))
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    return parser.parse_args()


def infer(checkpoint, args, loader, use_support_correction):
    args.use_support_correction = use_support_correction
    model = DLF(args).to(args.device)
    model.load_state_dict(torch.load(checkpoint, map_location=args.device), strict=True)
    model.eval()
    rows = []
    with torch.no_grad():
        for batch in loader:
            output = model(
                batch["text"].to(args.device),
                batch["audio"].to(args.device),
                batch["vision"].to(args.device),
                batch["padding_mask"].to(args.device),
            )
            labels = batch["labels"]["M"].reshape(-1).cpu().numpy()
            consensus = output["consensus_logit"].reshape(-1).cpu().numpy()
            support = output["support_delta"].reshape(-1).cpu().numpy()
            conflict = output["conflict_delta"].reshape(-1).cpu().numpy()
            prediction = output["output_logit"].reshape(-1).cpu().numpy()
            for index in range(len(labels)):
                after_support = consensus[index] + support[index]
                error_consensus = abs(consensus[index] - labels[index])
                error_support = abs(after_support - labels[index])
                error_final = abs(prediction[index] - labels[index])
                rows.append({
                    "id": str(batch["id"][index]),
                    "text": str(batch["raw_text"][index]),
                    "label": float(labels[index]),
                    "consensus": float(consensus[index]),
                    "support_delta": float(support[index]),
                    "conflict_delta": float(conflict[index]),
                    "prediction": float(prediction[index]),
                    "error_consensus": float(error_consensus),
                    "error_support": float(error_support),
                    "error_final": float(error_final),
                    "support_gain": float(error_consensus - error_support),
                    "conflict_gain": float(error_support - error_final),
                    "total_gain": float(error_consensus - error_final),
                })
    return rows


def summarize(rows):
    result = {}
    for field in ("error_consensus", "error_support", "error_final"):
        result[field] = float(np.mean([row[field] for row in rows]))
    for branch in ("support", "conflict", "total"):
        gains = np.array([row[f"{branch}_gain"] for row in rows])
        result[f"{branch}_mean_gain"] = float(gains.mean())
        result[f"{branch}_helpful_rate"] = float((gains > 1e-6).mean())
        result[f"{branch}_harmful_rate"] = float((gains < -1e-6).mean())
        result[f"{branch}_neutral_rate"] = float((np.abs(gains) <= 1e-6).mean())
    return result


def draw_dashboard(results, summaries, output_path):
    names = list(results)
    colors = ("#277da1", "#f94144")
    figure, axes = plt.subplots(2, 2, figsize=(14, 9))

    x = np.arange(3)
    width = 0.36
    for index, name in enumerate(names):
        summary = summaries[name]
        values = [summary[key] for key in ("error_consensus", "error_support", "error_final")]
        axes[0, 0].bar(x + (index - 0.5) * width, values, width, label=name, color=colors[index])
    axes[0, 0].set_xticks(x, ("Consensus", "+ Support", "+ Conflict"))
    axes[0, 0].set_ylabel("Mean absolute error")
    axes[0, 0].set_title("Error after each correction stage")
    axes[0, 0].legend()

    positions = np.arange(3)
    for index, name in enumerate(names):
        summary = summaries[name]
        helpful = np.array([summary[f"{branch}_helpful_rate"] for branch in ("support", "conflict", "total")])
        harmful = np.array([summary[f"{branch}_harmful_rate"] for branch in ("support", "conflict", "total")])
        offset = (index - 0.5) * width
        axes[0, 1].bar(positions + offset, helpful, width, color=colors[index], alpha=0.9, label=f"{name} helpful")
        axes[0, 1].bar(positions + offset, -harmful, width, color=colors[index], alpha=0.35, label=f"{name} harmful")
    axes[0, 1].axhline(0, color="black", linewidth=0.8)
    axes[0, 1].set_xticks(positions, ("Support", "Conflict", "Total"))
    axes[0, 1].set_ylabel("Rate (+ helpful / - harmful)")
    axes[0, 1].set_title("How often corrections help")
    axes[0, 1].legend(fontsize=8, ncols=2)

    bins = np.linspace(-1.5, 1.5, 61)
    for index, name in enumerate(names):
        gains = [row["total_gain"] for row in results[name]]
        axes[1, 0].hist(gains, bins=bins, alpha=0.55, color=colors[index], label=name)
    axes[1, 0].axvline(0, color="black", linewidth=0.8)
    axes[1, 0].set_xlabel("Consensus error - final error (> 0 is helpful)")
    axes[1, 0].set_ylabel("Samples")
    axes[1, 0].set_title("Distribution of total correction gain")
    axes[1, 0].legend()

    candidate_name = names[1]
    baseline_errors = np.array([row["error_final"] for row in results["baseline"]])
    candidate_errors = np.array([row["error_final"] for row in results[candidate_name]])
    axes[1, 1].scatter(baseline_errors, candidate_errors, s=12, alpha=0.45, color="#577590")
    limit = max(baseline_errors.max(), candidate_errors.max())
    axes[1, 1].plot([0, limit], [0, limit], color="black", linewidth=0.8)
    axes[1, 1].set_xlabel("Baseline final absolute error")
    axes[1, 1].set_ylabel(f"{candidate_name} final absolute error")
    axes[1, 1].set_title(f"Paired samples (below line favors {candidate_name})")

    figure.suptitle("CCDR correction-effect diagnostic")
    figure.tight_layout()
    figure.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def main():
    cli = parse_args()
    args = get_config_regression("DLF", "mosi", cli.config)
    args.device = torch.device(cli.device)
    args.feature_T = args.feature_A = args.feature_V = ""
    dataset = MMDataset(args, mode=cli.split)
    args.seq_lens = dataset.get_seq_len()
    loader = DataLoader(dataset, batch_size=cli.batch_size, shuffle=False)
    results = {
        "baseline": infer(cli.baseline, args, loader, use_support_correction=True),
        cli.candidate_name: infer(
            cli.candidate, args, loader, use_support_correction=False
        ),
    }
    summaries = {name: summarize(rows) for name, rows in results.items()}
    cli.output_dir.mkdir(parents=True, exist_ok=True)
    draw_dashboard(results, summaries, cli.output_dir / "correction_effect.png")
    (cli.output_dir / "summary.json").write_text(json.dumps(summaries, indent=2))

    fields = ["model", *results["baseline"][0].keys()]
    with (cli.output_dir / "samples.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for name, rows in results.items():
            for row in rows:
                writer.writerow({"model": name, **row})
    print(json.dumps(summaries, indent=2))
    print(f"Saved diagnostic to {cli.output_dir}")


if __name__ == "__main__":
    main()