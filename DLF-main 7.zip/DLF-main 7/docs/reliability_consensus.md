# Reliability-weighted consensus

Set `DLF.datasetParams.mosi.consensus_fusion` to `reliability` (enabled)
or `equal` (original architecture). Only the consensus pool learns modality
weights. Existing temporal pooling, support/conflict pools and losses remain.
The new MLP maps concatenated text/audio/vision summaries from 3H to H to 3;
softmax produces per-sample weights. The final layer starts at zero, so initial
weights are exactly 1/3. For H=50 this adds 7,703 parameters.

`consensus_modality_weights` is returned as [batch, 3] in text/audio/vision order.
Validation/test logs record sample-averaged weights and the fraction of samples
with any weight above 0.9. These are learned mixing coefficients, not calibrated
probabilities that a modality is reliable. No extra loss is added.

Run `python train.py` from the project root. Checkpoints get the suffix
`-reliability-consensus`, and CSV results `_reliability_consensus`. Existing
baseline artifacts remain separate; reruns of this same variant still share
the filename, so use separate save directories for repeated experiments.

New models need training. Old checkpoints load with `consensus_fusion=equal`;
strict loading into the new architecture correctly reports missing MLP weights.
The user-selected batch-averaged validation Loss is preserved.
