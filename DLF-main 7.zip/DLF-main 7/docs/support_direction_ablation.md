# Continuous gate with unrestricted support direction

This is a single-factor training ablation of the continuous-gated-support model.
It is a candidate, not a demonstrated improvement over the prior seed-1111
checkpoint (validation MAE 0.7062, test MAE 0.7221).

## Motivation

If consensus c=1, target y=0.2 and raw support correction r=-1, the continuous
gate target is 0.8. The original support sign loss relu(-sign(c) * support_delta)
penalizes this useful attenuation. Removing only that term tests whether this
competition limits training. It does not guarantee that support becomes useful.

## Configuration

- `use_support_direction_constraint: false`: remove support sign penalty.
- `true` or missing: preserve the previous objective exactly.
- `use_support_correction: true`: support prediction remains active.
- Gate mode remains continuous; gate/task weights remain 0.05/0.05.
- Conflict's original direction penalty and global effect weight 0.01 remain.
- All other losses, optimizer settings, architecture and checkpoint tensor
  shapes are unchanged. This is not a reinstatement of error-constraint or
  independent conflict-task supervision.

When disabled, support may either reinforce or attenuate consensus. Labels
supervise training only; inference still uses feature-predicted scales and heads.
Detached reference outputs do not freeze upstream shared feature encoders.

## Artifacts and comparison

The existing train.py entry uses the new configuration and adds
`-no-support-direction` / `_no_support_direction` to checkpoint / result names.
Previous continuous-gated-support weights and CSVs are not overwritten.
Setting the flag back to true restores the old objective AND old artifact names;
use a separate model/result/log directory when rerunning old configurations.
Within either variant, repeated runs and multiple seeds still share its checkpoint
name: use separate directories to avoid overwriting. Logs record the flag.

Compare matched seeds using the same validation-based selection protocol.
Do not select epochs or loss weights by test performance. The historical test
set has already been inspected repeatedly; new gains need independent validation,
not just another favorable test score. No full retraining of this ablation has
been completed at implementation time.

Gate supervision remains relative to consensus (not consensus+conflict), and
evaluation Loss still averages batch means. Those are separate experiments;
changing them here would confound this ablation.